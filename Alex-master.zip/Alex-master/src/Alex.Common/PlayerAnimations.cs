namespace Alex.Common
{
	public enum PlayerAnimations
	{
		SwingLeftArm,
		SwingRightArm
	}
}