﻿namespace Alex.Common.Utils
{
	public enum DiggingStatus
	{
		Started = 0,
		Cancelled = 1,
		Finished = 2,
		DropItemStack = 3,
		DropItem = 4,
		ShootArrow = 5,
		FinishEating = 5,
		SwapItemInHand = 6
	}
}