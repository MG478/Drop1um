namespace Alex.Common.Utils.Realms
{
	public class BaseRealmsApi { }
}