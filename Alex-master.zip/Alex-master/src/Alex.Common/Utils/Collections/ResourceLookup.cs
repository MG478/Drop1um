namespace Alex.Common.Utils.Collections
{
	/*public class ResourceLookup<T>
	{
		public bool TryGet(ResourceLocation location, out T value)
		{
			value = default;

			return false;
		}
		public bool TryAdd(ResourceLocation resourceLocation, T value)
		{
			
		}
	}*/
}