namespace Alex.Common.Items
{
	public enum ItemUseAction
	{
		Use,
		ClickBlock,
		ClickAir,
		RightClickBlock,
		RightClickAir
	}
}