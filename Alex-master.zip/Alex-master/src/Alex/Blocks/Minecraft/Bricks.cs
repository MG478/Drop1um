namespace Alex.Blocks.Minecraft
{
	public class Bricks : Block
	{
		public Bricks() : base()
		{
			Solid = true;
			Transparent = false;
			IsFullCube = true;
		}
	}
}