namespace Alex.Blocks.Minecraft
{
	public class PurpurPillar : Block
	{
		public PurpurPillar() : base()
		{
			Solid = true;
			Transparent = false;
			IsFullCube = true;
		}
	}
}