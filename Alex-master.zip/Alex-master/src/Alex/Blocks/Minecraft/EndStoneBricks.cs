namespace Alex.Blocks.Minecraft
{
	public class EndStoneBricks : Block
	{
		public EndStoneBricks() : base()
		{
			Solid = true;
			Transparent = false;
			IsFullCube = true;
		}
	}
}