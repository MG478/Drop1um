namespace Alex.Blocks.Minecraft
{
	public class Potatoes : Block
	{
		public Potatoes() : base()
		{
			Solid = false;
			Transparent = true;

			IsFullCube = false;
		}
	}
}