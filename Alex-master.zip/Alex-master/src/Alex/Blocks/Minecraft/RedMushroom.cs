namespace Alex.Blocks.Minecraft
{
	public class RedMushroom : Block
	{
		public RedMushroom() : base()
		{
			Solid = false;
			Transparent = true;
		}
	}
}