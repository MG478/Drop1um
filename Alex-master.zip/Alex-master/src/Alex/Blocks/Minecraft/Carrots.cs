namespace Alex.Blocks.Minecraft
{
	public class Carrots : Block
	{
		public Carrots() : base()
		{
			Solid = false;
			Transparent = true;
			IsFullCube = false;
		}
	}
}