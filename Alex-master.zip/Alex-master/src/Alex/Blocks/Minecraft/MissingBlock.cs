namespace Alex.Blocks.Minecraft
{
	public class MissingBlock : Block
	{
		public MissingBlock() { }
	}
}