namespace Alex.Blocks.Minecraft
{
	public class EnchantingTable : Block
	{
		public EnchantingTable() : base()
		{
			Solid = true;
			Transparent = true;

			CanInteract = true;
		}
	}
}