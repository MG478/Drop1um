﻿namespace Alex.Blocks.Minecraft.Liquid
{
	public class FlowingWater : Water
	{
		public FlowingWater(byte meta = 0) : base()
		{
			//BlockModel = new LiquidBlockModel()
			//{
			//	IsFlowing = true,
			//	Level = meta
			//};
		}
	}
}