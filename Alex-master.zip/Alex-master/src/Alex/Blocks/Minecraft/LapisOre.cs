namespace Alex.Blocks.Minecraft
{
	public class LapisOre : Block
	{
		public LapisOre() : base()
		{
			Solid = true;
			Transparent = false;
		}
	}
}