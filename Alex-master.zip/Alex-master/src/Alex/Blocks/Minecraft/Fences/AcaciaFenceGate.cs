namespace Alex.Blocks.Minecraft.Fences
{
	public class AcaciaFenceGate : FenceGate
	{
		public AcaciaFenceGate() : base(7370)
		{
			Solid = true;
			Transparent = true;
		}
	}
}