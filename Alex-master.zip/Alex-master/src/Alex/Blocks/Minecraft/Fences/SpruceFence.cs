namespace Alex.Blocks.Minecraft.Fences
{
	public class SpruceFence : Fence
	{
		public SpruceFence() : base() { }
	}
}