namespace Alex.Blocks.Minecraft.Fences
{
	public class SpruceFenceGate : FenceGate
	{
		public SpruceFenceGate() : base(7274)
		{
			Solid = true;
			Transparent = true;
		}
	}
}