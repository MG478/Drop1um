namespace Alex.Blocks.Minecraft.Fences
{
	public class DarkOakFenceGate : FenceGate
	{
		public DarkOakFenceGate() : base(7402) { }
	}
}