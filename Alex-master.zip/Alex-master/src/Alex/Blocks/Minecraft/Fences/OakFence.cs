﻿namespace Alex.Blocks.Minecraft.Fences
{
	public class OakFence : Fence
	{
		public OakFence() : base() { }
	}
}