using Alex.Blocks.Materials;

namespace Alex.Blocks.Minecraft.Buttons
{
	public class BirchButton : Button
	{
		public BirchButton() : base(5270)
		{
			BlockMaterial = Material.Wood;
		}
	}
}