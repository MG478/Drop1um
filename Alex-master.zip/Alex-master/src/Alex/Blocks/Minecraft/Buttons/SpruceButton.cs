using Alex.Blocks.Materials;

namespace Alex.Blocks.Minecraft.Buttons
{
	public class SpruceButton : Button
	{
		public SpruceButton() : base(5246)
		{
			BlockMaterial = Material.Wood;
		}
	}
}