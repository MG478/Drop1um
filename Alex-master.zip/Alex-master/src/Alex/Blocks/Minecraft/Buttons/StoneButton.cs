namespace Alex.Blocks.Minecraft.Buttons
{
	public class StoneButton : Button
	{
		public StoneButton() : base(3310) { }
	}
}