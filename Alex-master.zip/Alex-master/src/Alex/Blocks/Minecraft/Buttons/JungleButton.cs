using Alex.Blocks.Materials;

namespace Alex.Blocks.Minecraft.Buttons
{
	public class JungleButton : Button
	{
		public JungleButton() : base(5294)
		{
			BlockMaterial = Material.Wood;
		}
	}
}