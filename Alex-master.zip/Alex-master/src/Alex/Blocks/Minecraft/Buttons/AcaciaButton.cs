using Alex.Blocks.Materials;

namespace Alex.Blocks.Minecraft.Buttons
{
	public class AcaciaButton : Button
	{
		public AcaciaButton() : base(5318)
		{
			BlockMaterial = Material.Wood;
		}
	}
}