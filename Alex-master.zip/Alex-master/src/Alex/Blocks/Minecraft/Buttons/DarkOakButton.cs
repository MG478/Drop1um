using Alex.Blocks.Materials;

namespace Alex.Blocks.Minecraft.Buttons
{
	public class DarkOakButton : Button
	{
		public DarkOakButton() : base(5342)
		{
			BlockMaterial = Material.Wood;
		}
	}
}