namespace Alex.Blocks.Minecraft
{
	public class Conduit : Block
	{
		public Conduit()
		{
			Luminance = 15;
		}
	}
}