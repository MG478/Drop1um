namespace Alex.Blocks.Minecraft
{
	public class MobSpawner : Block
	{
		public MobSpawner() : base()
		{
			Solid = true;
			Transparent = true;
			Luminance = 1;
		}
	}
}