namespace Alex.Blocks.Minecraft.Decorations
{
	public class ActivatorRail : Rail
	{
		public ActivatorRail() : base()
		{
			Solid = false;
			Transparent = true;
		}
	}
}