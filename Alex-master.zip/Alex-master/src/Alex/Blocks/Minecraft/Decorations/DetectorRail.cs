namespace Alex.Blocks.Minecraft.Decorations
{
	public class DetectorRail : Rail
	{
		public DetectorRail() : base()
		{
			Solid = false;
			Transparent = true;
		}
	}
}