namespace Alex.Blocks.Minecraft
{
	public class Shroomlight : Block
	{
		public Shroomlight()
		{
			Luminance = 15;
			Solid = true;
			Transparent = false;
		}
	}
}