namespace Alex.Blocks.Minecraft
{
	public class Gravel : Block
	{
		public Gravel() : base()
		{
			Solid = true;
			Transparent = false;
		}
	}
}