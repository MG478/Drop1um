namespace Alex.Blocks.Minecraft
{
	public class Lectern : Block
	{
		public Lectern()
		{
			Solid = true;
			Transparent = true;
		}
	}
}