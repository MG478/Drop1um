namespace Alex.Blocks.Minecraft.Slabs
{
	public class JungleSlab : WoodenSlab
	{
		public JungleSlab() : base() { }
	}
}