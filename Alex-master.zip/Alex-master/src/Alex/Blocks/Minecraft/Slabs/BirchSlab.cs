namespace Alex.Blocks.Minecraft.Slabs
{
	public class BirchSlab : WoodenSlab
	{
		public BirchSlab() : base() { }
	}
}