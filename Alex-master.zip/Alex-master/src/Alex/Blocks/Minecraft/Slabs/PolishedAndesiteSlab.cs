namespace Alex.Blocks.Minecraft.Slabs
{
	public class PolishedAndesiteSlab : Slab
	{
		/// <inheritdoc />
		public PolishedAndesiteSlab() : base() { }
	}
}