namespace Alex.Blocks.Minecraft.Slabs
{
	public class OakSlab : WoodenSlab
	{
		public OakSlab() : base() { }
	}
}