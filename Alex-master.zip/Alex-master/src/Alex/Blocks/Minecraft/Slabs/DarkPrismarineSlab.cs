namespace Alex.Blocks.Minecraft.Slabs
{
	public class DarkPrismarineSlab : Slab
	{
		public DarkPrismarineSlab() : base() { }
	}
}