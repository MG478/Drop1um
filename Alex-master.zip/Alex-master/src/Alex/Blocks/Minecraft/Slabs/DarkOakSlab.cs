namespace Alex.Blocks.Minecraft.Slabs
{
	public class DarkOakSlab : WoodenSlab
	{
		public DarkOakSlab() : base() { }
	}
}