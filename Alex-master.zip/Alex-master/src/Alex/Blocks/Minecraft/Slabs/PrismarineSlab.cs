namespace Alex.Blocks.Minecraft.Slabs
{
	public class PrismarineSlab : Slab
	{
		public PrismarineSlab() : base() { }
	}
}