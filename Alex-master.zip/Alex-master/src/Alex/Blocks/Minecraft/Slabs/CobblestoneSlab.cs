namespace Alex.Blocks.Minecraft.Slabs
{
	public class CobblestoneSlab : Slab
	{
		public CobblestoneSlab() : base() { }
	}
}