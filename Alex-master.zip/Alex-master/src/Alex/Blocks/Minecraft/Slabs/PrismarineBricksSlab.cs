namespace Alex.Blocks.Minecraft.Slabs
{
	public class PrismarineBricksSlab : Slab
	{
		public PrismarineBricksSlab() : base() { }
	}
}