namespace Alex.Blocks.Minecraft.Slabs
{
	public class AndesiteSlab : Slab
	{
		/// <inheritdoc />
		public AndesiteSlab() : base() { }
	}
}