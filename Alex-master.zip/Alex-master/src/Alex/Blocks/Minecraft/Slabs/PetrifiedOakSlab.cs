namespace Alex.Blocks.Minecraft.Slabs
{
	public class PetrifiedOakSlab : Slab
	{
		public PetrifiedOakSlab() : base() { }
	}
}