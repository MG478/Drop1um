namespace Alex.Blocks.Minecraft.Slabs
{
	public class AcaciaSlab : WoodenSlab
	{
		public AcaciaSlab() : base() { }
	}
}