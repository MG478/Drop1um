namespace Alex.Blocks.Minecraft.Slabs
{
	public class BrickSlab : Slab
	{
		public BrickSlab() : base() { }
	}
}