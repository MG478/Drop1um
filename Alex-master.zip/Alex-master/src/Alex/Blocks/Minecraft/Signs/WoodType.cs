namespace Alex.Blocks.Minecraft.Signs;

public enum WoodType
{
	Oak,
	Spruce,
	Birch,
	Jungle,
	Acacia,
	DarkOak,
	Crimson,
	Warped
}