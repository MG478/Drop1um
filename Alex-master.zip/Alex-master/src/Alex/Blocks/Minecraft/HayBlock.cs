using Alex.Blocks.Materials;

namespace Alex.Blocks.Minecraft
{
	public class HayBlock : Block
	{
		public HayBlock() : base()
		{
			Solid = true;
			Transparent = false;

			BlockMaterial = Material.Grass;
		}
	}
}