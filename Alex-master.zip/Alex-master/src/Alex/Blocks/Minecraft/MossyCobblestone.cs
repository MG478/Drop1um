namespace Alex.Blocks.Minecraft
{
	public class MossyCobblestone : Block
	{
		public MossyCobblestone() : base()
		{
			Solid = true;
			Transparent = false;
		}
	}
}