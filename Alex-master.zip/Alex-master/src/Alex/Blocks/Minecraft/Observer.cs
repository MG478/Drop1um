namespace Alex.Blocks.Minecraft
{
	public class Observer : Block
	{
		public Observer() : base()
		{
			Solid = true;
			Transparent = true;
		}
	}
}