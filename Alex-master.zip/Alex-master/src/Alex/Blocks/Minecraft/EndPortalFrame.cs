namespace Alex.Blocks.Minecraft
{
	public class EndPortalFrame : Block
	{
		public EndPortalFrame() : base()
		{
			Solid = true;
			Transparent = false;
			Luminance = 1;
		}
	}
}