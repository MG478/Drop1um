﻿using Alex.Blocks.Materials;

namespace Alex.Blocks.Minecraft
{
	public class BubbleColumn : Block
	{
		public BubbleColumn() : base()
		{
			base.BlockMaterial = Material.BubbleColumn;
		}
	}
}