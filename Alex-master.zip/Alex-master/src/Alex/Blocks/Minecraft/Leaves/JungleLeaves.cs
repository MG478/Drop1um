namespace Alex.Blocks.Minecraft.Leaves
{
	public class JungleLeaves : Leaves
	{
		public JungleLeaves() : base(126) { }
	}
}