namespace Alex.Blocks.Minecraft.Leaves
{
	public class AcaciaLeaves : Leaves
	{
		public AcaciaLeaves() : base(130) { }
	}
}