namespace Alex.Blocks.Minecraft.Leaves
{
	public class SpruceLeaves : Leaves
	{
		public SpruceLeaves() : base(118) { }
	}
}