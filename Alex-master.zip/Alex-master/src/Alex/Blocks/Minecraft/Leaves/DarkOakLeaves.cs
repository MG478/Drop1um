namespace Alex.Blocks.Minecraft.Leaves
{
	public class DarkOakLeaves : Leaves
	{
		public DarkOakLeaves() : base(134) { }
	}
}