namespace Alex.Blocks.Minecraft.Leaves
{
	public class OakLeaves : Leaves
	{
		public OakLeaves() : base(114) { }
	}
}