namespace Alex.Blocks.Minecraft.Leaves
{
	public class BirchLeaves : Leaves
	{
		public BirchLeaves() : base(122) { }
	}
}