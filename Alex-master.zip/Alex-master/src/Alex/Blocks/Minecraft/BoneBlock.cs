namespace Alex.Blocks.Minecraft
{
	public class BoneBlock : Block
	{
		public BoneBlock() : base()
		{
			Solid = true;
			Transparent = false;
			IsFullCube = true;
		}
	}
}