namespace Alex.Blocks.Minecraft
{
	public class Beetroots : AgingPlantBlock
	{
		public Beetroots() : base()
		{
			Solid = false;
			Transparent = true;
			IsFullCube = false;
		}
	}
}