namespace Alex.Blocks.Minecraft
{
	public class NetherQuartzOre : Block
	{
		public NetherQuartzOre() : base()
		{
			Solid = true;
			Transparent = false;
			IsFullCube = true;
		}
	}
}