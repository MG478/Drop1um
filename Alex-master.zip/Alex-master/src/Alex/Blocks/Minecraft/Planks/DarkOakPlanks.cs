using Alex.Blocks.Minecraft.Signs;

namespace Alex.Blocks.Minecraft.Planks
{
	public class DarkOakPlanks : Planks
	{
		public DarkOakPlanks() : base(WoodType.DarkOak) { }
	}
}