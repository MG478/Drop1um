namespace Alex.Blocks.Minecraft.Plants
{
	public class PottedDeadBush : PottedPlantBlock { }
}