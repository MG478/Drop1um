namespace Alex.Blocks.Minecraft.Plants
{
	public class MelonStem : Block
	{
		public MelonStem() : base()
		{
			Solid = false;
			Transparent = true;
		}
	}
}