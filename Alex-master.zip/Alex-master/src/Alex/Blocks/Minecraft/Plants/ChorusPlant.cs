namespace Alex.Blocks.Minecraft
{
	public class ChorusPlant : Block
	{
		public ChorusPlant() : base()
		{
			Solid = true;
			Transparent = true;
		}
	}
}