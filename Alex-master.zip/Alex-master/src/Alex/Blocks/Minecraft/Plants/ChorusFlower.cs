namespace Alex.Blocks.Minecraft
{
	public class ChorusFlower : Block
	{
		public ChorusFlower() : base()
		{
			Solid = true;
			Transparent = true;
		}
	}
}