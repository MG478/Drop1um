namespace Alex.Blocks.Minecraft.Plants
{
	public class Pumpkin : Block
	{
		public Pumpkin() : base()
		{
			Solid = true;
			Transparent = false;
		}
	}
}