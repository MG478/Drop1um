namespace Alex.Blocks.Minecraft.Plants
{
	public class PottedPlantBlock : Block
	{
		protected PottedPlantBlock()
		{
			Transparent = true;
			IsFullCube = false;
		}
	}
}