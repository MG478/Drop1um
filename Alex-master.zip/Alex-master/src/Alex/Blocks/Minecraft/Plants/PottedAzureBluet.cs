namespace Alex.Blocks.Minecraft.Plants;

public class PottedAzureBluet : PottedPlantBlock
{
	
}

public class PottedBlueOrchid : PottedPlantBlock
{
	
}