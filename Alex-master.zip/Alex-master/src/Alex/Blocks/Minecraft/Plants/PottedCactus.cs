namespace Alex.Blocks.Minecraft.Plants
{
	public class PottedCactus : PottedPlantBlock { }
}