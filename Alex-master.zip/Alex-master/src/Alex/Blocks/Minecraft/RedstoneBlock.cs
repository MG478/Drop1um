namespace Alex.Blocks.Minecraft
{
	public class RedstoneBlock : Block
	{
		public RedstoneBlock() : base()
		{
			Solid = true;
			Transparent = false;

			;
		}
	}
}