namespace Alex.Blocks.Minecraft
{
	public class LightBlock : Block
	{
		public LightBlock()
		{
			HasHitbox = false;
			Renderable = false;
		}
	}
}