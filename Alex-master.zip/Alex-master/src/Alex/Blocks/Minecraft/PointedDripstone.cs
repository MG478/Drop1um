namespace Alex.Blocks.Minecraft
{
	public class PointedDripstone : Block
	{
		public PointedDripstone()
		{
			Transparent = true;
		}
	}
}