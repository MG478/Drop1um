namespace Alex.Audio
{
	public enum Sounds { }
}