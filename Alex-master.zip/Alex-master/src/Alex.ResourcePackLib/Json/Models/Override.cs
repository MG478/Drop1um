﻿using System.Collections.Generic;

namespace Alex.ResourcePackLib.Json.Models
{
	public class Override
	{
		public Dictionary<string, double> Predicate;
		public string Model;
	}
}