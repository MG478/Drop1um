﻿namespace Alex.ResourcePackLib.Json.Models.Items
{
	public enum GuiLight
	{
		Front = 0,
		Side = 1
	}
}