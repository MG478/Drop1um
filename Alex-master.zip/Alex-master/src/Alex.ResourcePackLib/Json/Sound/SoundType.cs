namespace Alex.ResourcePackLib.Json.Sound
{
	public enum SoundType
	{
		Event
	};
}