﻿using System;
using Alex.ResourcePackLib.Json.Models.Items;
using Newtonsoft.Json;

namespace Alex.ResourcePackLib.Json.Converters
{
	// public class DisplayPositionConverter : JsonConverter<DisplayPosition>
	// {
	//     public override void WriteJson(JsonWriter writer, DisplayPosition value, JsonSerializer serializer)
	//     {
	//         
	//     }
	//
	//     public override DisplayPosition ReadJson(JsonReader reader, Type objectType, DisplayPosition existingValue, bool hasExistingValue,
	//         JsonSerializer serializer)
	//     {
	//         var asString = reader.ReadAsString();
	//         
	//     }
	// }
}