using System;

namespace Alex.ResourcePackLib.Exceptions
{
	public class InvalidMCPackException : Exception
	{
		public InvalidMCPackException(string message) : base(message) { }
	}
}