using System;

namespace Alex.ResourcePackLib.Exceptions
{
	public class InvalidResourcePackException : Exception { }
}