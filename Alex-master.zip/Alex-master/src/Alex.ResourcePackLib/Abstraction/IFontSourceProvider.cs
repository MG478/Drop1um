﻿namespace Alex.ResourcePackLib.Abstraction
{
    public interface IFontSourceProvider
    {
        BitmapFontSource[] FontSources { get; }
    }
}