﻿namespace Alex.ResourcePackLib
{
	public enum ResourcePackType
	{
		Java,
		Bedrock,
		Unknown
	}
}